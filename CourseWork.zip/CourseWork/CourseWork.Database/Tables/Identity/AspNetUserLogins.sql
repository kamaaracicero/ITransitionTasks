﻿CREATE TABLE [dbo].[AspNetUserLogins]
(
	[LoginProvider] NVARCHAR(450) NOT NULL,
	[ProviderKey] NVARCHAR(450) NOT NULL,
	[ProviderDisplayName] NVARCHAR(MAX) NULL,
	[UserId] NVARCHAR(450) NOT NULL,
	CONSTRAINT pk_AspNetUserLogins PRIMARY KEY ([LoginProvider],[ProviderKey])
)
