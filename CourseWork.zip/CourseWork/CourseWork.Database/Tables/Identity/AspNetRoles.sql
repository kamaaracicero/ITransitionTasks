﻿CREATE TABLE [dbo].[AspNetRoles]
(
	[Id] NVARCHAR(450) NOT NULL,
    [Name] NVARCHAR(256) NULL,
    [NormalizedName] NVARCHAR(256) NULL,
    [ConcurrencyStamp] NVARCHAR(MAX) NULL,
    CONSTRAINT pk_AspNetRoles PRIMARY KEY ([Id])
)