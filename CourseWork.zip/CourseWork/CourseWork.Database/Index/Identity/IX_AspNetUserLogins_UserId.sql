﻿CREATE INDEX [IX_AspNetUserLogins_UserId]
	ON [dbo].[AspNetUserLogins]
	([UserId])
