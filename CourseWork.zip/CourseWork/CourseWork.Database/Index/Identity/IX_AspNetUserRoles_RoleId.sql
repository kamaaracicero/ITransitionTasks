﻿CREATE INDEX [IX_AspNetUserRoles_RoleId]
	ON [dbo].[AspNetUserRoles]
	([RoleId])
