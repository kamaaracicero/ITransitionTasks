﻿CREATE INDEX [IX_AspNetRoleClaims_RoleId]
	ON [dbo].[AspNetRoleClaims]
	([RoleId])
