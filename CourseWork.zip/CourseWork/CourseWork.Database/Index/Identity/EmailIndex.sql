﻿CREATE INDEX [EmailIndex]
	ON [dbo].[AspNetUsers]
	([NormalizedEmail])
