﻿CREATE INDEX [IX_AspNetUserClaims_UserId]
	ON [dbo].[AspNetUserClaims]
	([UserId])
