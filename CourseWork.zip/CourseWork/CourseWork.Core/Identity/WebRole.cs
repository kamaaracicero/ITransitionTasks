﻿using Microsoft.AspNetCore.Identity;

namespace CourseWork.Core.Identity
{
    public sealed class WebRole : IdentityRole
    {
    }
}
