﻿using CourseWork.Core;
using System.Collections.Generic;

namespace CourseWork.Web.Models.Tags
{
    public class TagsViewModel
    {
        public List<Tag> Tags { get; set; }
    }
}
