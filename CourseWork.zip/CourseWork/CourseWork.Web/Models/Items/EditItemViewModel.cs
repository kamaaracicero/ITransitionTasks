﻿using CourseWork.Core;
using CourseWork.Core.AdditionalFields;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CourseWork.Web.Models.Items
{
    public class EditItemViewModel
    {
        public EditItemViewModel(CollectionItem item, IEnumerable<IAdditionalField> fields)
        {

        }
    }
}
