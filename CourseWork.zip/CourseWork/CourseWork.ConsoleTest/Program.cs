﻿using CourseWork.BusinessLogic.Services;
using CourseWork.Core;
using CourseWork.DataAccess.DbContexts;
using Microsoft.EntityFrameworkCore;
using System;

namespace CourseWork.ConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
