﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("CourseWork.BusinessLogic")]
[assembly: InternalsVisibleTo("CourseWork.Web")]