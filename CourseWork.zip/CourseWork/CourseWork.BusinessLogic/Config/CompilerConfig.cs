﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("CourseWork.Web")]